# Finance Monitoring AI System

AI-powered finance monitor with receipt extraction, review queue, and duplicate detection.

**Stack:** Next.js 14 · FastAPI · Supabase (PostgreSQL) · Google Gemini · Vercel · Render

---

## Repo Structure

```
Finance-Monitoring-AI-System/
├── frontend/          # Next.js 14 app
├── backend/           # FastAPI service
├── supabase/
│   └── migrations/    # SQL migration files (run in order)
├── .github/
│   ├── workflows/     # CI/CD GitHub Actions
│   └── ISSUE_TEMPLATE/
├── scripts/           # Dev setup helpers
├── docs/              # Architecture + API docs
└── .env.example       # All required env vars (no secrets)
```

---

## Branch Strategy

| Branch | Purpose | Deploy target |
|--------|---------|---------------|
| `main` | Production-ready code | Vercel prod · Render prod |
| `develop` | Integration branch | Vercel preview · Render staging |
| `feat/<name>` | Feature work | PR → develop |
| `fix/<name>` | Bug fixes | PR → develop |
| `hotfix/<name>` | Urgent prod fixes | PR → main (then backmerge to develop) |

**Rules:**
- No direct push to `main` or `develop`
- All PRs require at least 1 reviewer approval
- CI must pass before merge
- Squash merge into `develop`, merge commit into `main`

---

## Quick Start (Local Dev)

```bash
# 1. Clone
git clone https://github.com/Migspajela23/Finance-Monitoring-AI-System.git
cd Finance-Monitoring-AI-System

# 2. Copy env files
cp .env.example .env
cp frontend/.env.example frontend/.env.local
cp backend/.env.example backend/.env

# 3. Fill in secrets in each .env file

# 4. Run the full local setup script
bash scripts/dev-setup.sh
```

---

## Required GitHub Secrets

Set these in **Settings → Secrets and variables → Actions**:

```
SUPABASE_ACCESS_TOKEN
SUPABASE_DB_PASSWORD
SUPABASE_PROJECT_ID
SUPABASE_URL
SUPABASE_SERVICE_KEY
GEMINI_API_KEY
RENDER_API_KEY
RENDER_SERVICE_ID
VERCEL_TOKEN
VERCEL_ORG_ID
VERCEL_PROJECT_ID
SNYK_TOKEN
SENTRY_DSN
LOGTAIL_TOKEN
```
